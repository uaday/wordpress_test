<?php
/**
 * Created by PhpStorm.
 * User: sudipta
 * Date: 10/29/2018
 * Time: 11:43 PM
 */
require_once(get_template_directory().'/inc/enqueue.php');